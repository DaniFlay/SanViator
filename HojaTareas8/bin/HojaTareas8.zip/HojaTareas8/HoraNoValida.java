package HojaTareas8;

public class HoraNoValida extends Exception{

	public HoraNoValida() {
		
	}
	public String toString() {
		return "Hora no valida";
	}
}
