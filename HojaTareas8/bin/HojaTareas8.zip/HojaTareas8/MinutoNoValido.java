package HojaTareas8;

public class MinutoNoValido extends Exception {

	public MinutoNoValido() {
		
	}
	public String toString() {
		return "Minutos no válidos";
	}
}
