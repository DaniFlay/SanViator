package HojaTareas8;

public class EtiquetaNoValida extends Exception {
	public EtiquetaNoValida() {
	}
	@Override
	public String toString() {
		return "Etiqueta No Valida";
	}
	
}
