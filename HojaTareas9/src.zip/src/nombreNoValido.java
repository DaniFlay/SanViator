
public class nombreNoValido extends Exception{
public nombreNoValido() {
		
	}
	public String toString() {
		return "La persona ya existe";
	}
}
